from django.apps import AppConfig


class CyberbullyingConfig(AppConfig):
    name = 'CyberBullying'
