from django.db import models
'''
class users(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    contact_no = models.CharField(max_length=12)
    email = models.CharField(max_length=50)
    adddress = models.CharField(max_length=50)
    status = models.CharField(max_length=30)
    
class posts(models.Model):
    sender = models.CharField(max_length=50)
    filename = models.CharField(max_length=50)
    msg = models.CharField(max_length=300)
    posttime = models.TimeField()
    status = models.CharField(max_length=50)
'''